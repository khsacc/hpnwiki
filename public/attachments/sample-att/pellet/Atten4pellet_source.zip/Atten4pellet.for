	program Atten4pellet

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!
!       Atten4pellet
!       
!	This program calculates the  flight path lengths of scattered neutron
!	pathed throgh V pellet 
!	as a function of gamma (longitude) and nu (latitude)
!
!	v1.0     30/Dec/2012  First draft (modified from Atten4pow)
!	v2.0	 06/Jan/2013  applying Gauss-Legendre quadratures
!	written by K. Komatsu (U of Tokyo)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	implicit none

	integer i,j,k,g,n,ns,ii
	integer numsp,numdir,numtof	!number of sampling points & directions, and tof
	integer nstep
	real zps,rps			!centre and radius of pellet
	real rad,deg
	real px,py,pz			!sampling point
	real ndx,ndy,ndz		!diffraction direction vector
	real sinth,dz,z1			!z coordinate of cross point of nd and surface 1
	real gamma,gammas,gammae,gammastep,nu,nus,nue,nustep		!longitude and latitude of diffraction vector
	real xmin,xmax,ymin,ymax,zmin,zmax,sstep,stepmin
	real xi(100),wi(100),xj(100),wj(100),xk(100),wk(100)
	real lam,mua,mub		!lambda, mu(lam) = mua * lam + mub
	real tof,tofs,tofe,tofstep	!start, end, step of tof
	real tinc,ts1,ts2,t		!flight path length
	real suma(50000),sumw		!summation of a = exp(-mu(lam) t)
	real avea			!average of a = (1/numsp*numdir)��exp(-mu(lam) t)
	real a,b,c			!a t^2 + b t + c = 0
	real V
	integer t1, t2, t_rate, t_max, diff
	
	character*80 ofile

	rad = 3.141592653589793/180
	deg = 180/3.141592653589793
	
	write(*,*)' ///////////////////////////////////////  ' 
	write(*,*)' '
	write(*,*)' Atten4pellet'  
	write(*,*)' v1.0  30/dec/2012'
	write(*,*)' '
	write(*,*)' ///////////////////////////////////////  ' 

	write(*,*)' '
	write(*,*)'Enter centre and radius of the pellet surface'
	read(*,*)zps,rps

	write(*,*)' '
	write(*,*)'Enter attenuation coefficient (mua&mub) of sample, mu(lam) = mua * lam + mub'
	read(*,*)mua,mub

	write(*,*)' '
	write(*,*)'Enter start,end and step of tof'
	read(*,*)tofs,tofe,tofstep

	write(*,*)' '
	write(*,*)'Enter start and end angle of gamma(longitude), and their step (in deg.)'
	read(*,*)gammas,gammae,gammastep

	gammas = gammas * rad       
	gammae = gammae * rad
	gammastep = gammastep * rad

	write(*,*)' '
	write(*,*)'Enter start and end angle of nu(latitude), and their step (in deg.)'
	read(*,*)nus,nue,nustep
	
	nus = nus * rad		
	nue = nue * rad
	nustep = nustep * rad
	
	write(*,*)' '
	write(*,*)'Enter numbber of step for Gauss-Legendre quadratures'
	read(*,*)nstep

	write(*,*)' ' 
	write(*,*)'Enter output filename without extention'
	read(*,'(a70)')ofile

	call lstring2(ofile,j)
	ofile=ofile(1:j)//'.dat'

	call lstring2(ofile,j) 
	  open(unit=12,file=ofile(1:j),status='replace')

!	open(unit=13,file='sp_GL.dat',status='replace')
!	write(13,*)'    px        py        pz    '

	call system_clock(t1)

	do i=1,50000
	   suma(i)=0
	end do
	sumw = 0

	numsp=0
	numdir=0

	do gamma = gammas, gammae, gammastep	
	do nu = nus, nue, nustep
	
	write(*,*) 'gamma :',gamma*deg,'  nu:',nu*deg

	numdir = numdir + 1
	!calc diffraction vector
	ndx = cos(nu)*sin(gamma)
	ndy = sin(gamma)
	ndz = cos(nu)*cos(gamma)

	!calc a
	a = ndx*ndx + ndy*ndy + ndz*ndz
	!calc sinth
	sinth = sin(0.5*acos(cos(gamma)*cos(nu)))	

	! calculate x and w of Gauss-Legendre quadratures 
	xmin = - (rps*rps - zps*zps)**0.5
	xmax = - xmin


	call GAULEG(xmin,xmax,xi,wi,nstep)
	ns = nstep

	do i=1,ns
	    px = xi(i)
	    ymin = - (rps*rps - zps*zps - px*px)**0.5
	    ymax = - ymin

	    call GAULEG(ymin,ymax,xj,wj,nstep)

	    do j=1,ns
		py = xj(j)
		zmin = -(rps*rps - px*px - py*py)**0.5 + zps
		zmax = - zmin

		call GAULEG(zmin,zmax,xk,wk,nstep)

		do k=1,ns
		    pz = xk(k)
!		    write(13,'(3F10.6)')px,py,pz
		    !criteria for sampling point in the pellet or not ! <- just in case
		    if ((px*px+py*py).gt.rps*rps) cycle
		    z1=zps-(rps*rps-px*px-py*py)**0.5
		    
		    if ((pz.lt.z1).or.(pz.gt.-z1)) cycle     ! <- just in case
			
		    numsp = numsp + 1

		    !calc pathlength for incident beam
		    tinc = pz + (rps*rps-px*px-py*py)**0.5 - zps

		    !calc b and c for surface 1
		    b = 2*(px*ndx + py*ndy + (pz-zps)*ndz)
		    c = px*px + py*py + (pz-zps)*(pz-zps) - rps*rps
		    !calc pathlenght for surace 1
		    ts1 = (-b+(b*b-4*a*c)**0.5)/(2*a)
		    
		    !calc b and c for surface 2
		    b = 2*(px*ndx + py*ndy + (pz+zps)*ndz)
		    c = px*px + py*py + (pz+zps)*(pz+zps) - rps*rps
		    !calc pathlenght for surace 2
		    ts2 = (-b+(b*b-4*a*c)**0.5)/(2*a)

		    dz = pz + ts1*ndz
		    if (dz.le.0) then
			t=tinc+ts1
		    else
			t=tinc+ts2
		    end if

		    numtof = 1
		    !calc lam for each tof , lam = t90 * h sin(th)/(mL(90) sin(45))
		    do tof=tofs,tofe,tofstep
			lam = tof * sinth * 0.000211119501  !(0.000211119501 = 10^10[m2ang]*10^-6[sec2us]* h/ml(90)sin(45)) 
			suma(numtof)=suma(numtof) + wi(i)*wj(j)*wk(k)*exp(-(mua*lam + mub)*t)
			numtof = numtof + 1
		    end do  ! tof
		    sumw = sumw + wi(i)*wj(j)*wk(k)
		end do  ! pz
	    end do  !py
	end do !px
			

	end do  !nu
	end do  !gamma

	!output
	numtof = 1
	write(*,*)'numsp:',numsp,' ','numdir:',numdir
	!calculate V
	V = 2*3.141592653589793*(rps-zps)**2*(2*rps+zps)/3
	write(*,*)'V:',V,' sumw:',sumw/numdir
	do tof = tofs,tofe,tofstep
!	    avea=suma(numtof)/V/numdir
	    avea=suma(numtof)/sumw/numdir
	    write(12,'(2F10.4)')tof,avea
	    numtof = numtof + 1
	end do

	close(12)

	 call system_clock(t2, t_rate, t_max)  
	  if ( t2 < t1 ) then
	    diff = t_max - t1 + t2
	  else
	    diff = t2 - t1
	  endif
	  print "(A, F10.3)", "time it took was:", diff/dble(t_rate)

	stop
	end
	
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      SUBROUTINE GAULEG(X1,X2,X,W,N) 
      IMPLICIT REAL*8 (A-H,O-Z) 
      REAL X1,X2,X(N),W(N) 
      PARAMETER (EPS=3.D-8) 
      M=(N+1)/2 
      XM=0.5D0*(X2+X1) 
      XL=0.5D0*(X2-X1) 
      DO I=1,M 
        Z=COS(3.141592654D0*(I-.25D0)/(N+.5D0)) 
	  do while(abs(Z-Z1).gt.EPS)
          P1=1.D0 
          P2=0.D0 
          DO J=1,N 
            P3=P2 
            P2=P1 
            P1=((2.D0*J-1.D0)*Z*P2-(J-1.D0)*P3)/J 
	  end do
          PP=N*(Z*P1-P2)/(Z*Z-1.D0) 
          Z1=Z 
          Z=Z1-P1/PP 
	  end do
        X(I)=XM-XL*Z 
        X(N+1-I)=XM+XL*Z 
        W(I)=2.D0*XL/((1.D0-Z*Z)*PP*PP) 
        W(N+1-I)=W(I) 
      end do
      RETURN 
      END 

