gfortran -c getFP.f90
gfortran -c getlimit.f90
gfortran Atten4pow.f90 gaulegf.o getlimit.o getFP.o getT.o getT4quartic.o quartic.o -o Atten4powDT.exe
