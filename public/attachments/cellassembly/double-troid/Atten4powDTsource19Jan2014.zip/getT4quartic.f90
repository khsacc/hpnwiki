!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! This subroutine calculate path length from p to q for surface 7-10
! using a subroutine 'quartic' to find root for quartic equation.
! 
!	p (4)   (i) : point vector of sampling point
!	d (4)   (i) : unit vector of diffraction 
!	xc, zc, r  (i) : geometrical parameters of surface 7&9
!	t1, t2  (o) : path length t form p to q
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	subroutine getT4quartic(p,d,xc,zc,r,t1,t2)

	implicit none
	real, dimension(4), intent(in) :: p, d   	! 1:x, 2:y, 3:z, 4: 1
	real, intent(in) :: xc, zc, r			!  ((x^2+y^2)^0.5 - xc)^2 + (z - zc)^2 = r^2)
	real, intent(out) :: t1,t2			! 2 cross point
	real(8) :: dd(0:4), sol(4), soli(4)		! for calc roots of quartic eq., ax^4 + bx^3 + cx^2 + dx + e = 0, dd(4) = a
	integer :: Nsol					! # of real solution
	integer :: tloc(1)				! location pointer

	dd(0) = p(1)**4+2*p(1)**2*p(2)**2+p(2)**4+2*p(1)**2*p(3)**2+2*p(2)**2*p(3)**2+p(3)**4-2*p(1)**2*r**2-2*p(2)**2*r**2 &
& -2*p(3)**2*r**2+r**4-2*p(1)**2*xc**2-2*p(2)**2*xc**2+2*p(3)**2*xc**2-2*r**2*xc**2+xc**4-4*p(1)**2*p(3)*zc-4*p(2)**2*p(3)*zc &
& -4*p(3)**3*zc+4*p(3)*r**2*zc-4*p(3)*xc**2*zc+2*p(1)**2*zc**2+2*p(2)**2*zc**2+6*p(3)**2*zc**2-2*r**2*zc**2+2*xc**2*zc**2 &
& -4*p(3)*zc**3+zc**4

	dd(1) = 4*d(1)*p(1)**3+4*d(2)*p(1)**2*p(2)+4*d(1)*p(1)*p(2)**2+4*d(2)*p(2)**3+4*d(3)*p(1)**2*p(3)+4*d(3)*p(2)**2*p(3) &
& +4*d(1)*p(1)*p(3)**2+4*d(2)*p(2)*p(3)**2+4*d(3)*p(3)**3-4*d(1)*p(1)*r**2-4*d(2)*p(2)*r**2-4*d(3)*p(3)*r**2-4*d(1)*p(1)*xc**2 &
& -4*d(2)*p(2)*xc**2+4*d(3)*p(3)*xc**2-4*d(3)*p(1)**2*zc-4*d(3)*p(2)**2*zc-8*d(1)*p(1)*p(3)*zc-8*d(2)*p(2)*p(3)*zc &
& -12*d(3)*p(3)**2*zc+4*d(3)*r**2*zc-4*d(3)*xc**2*zc+4*d(1)*p(1)*zc**2+4*d(2)*p(2)*zc**2+12*d(3)*p(3)*zc**2-4*d(3)*zc**3

	dd(2) = 6*d(1)**2*p(1)**2+2*d(2)**2*p(1)**2+2*d(3)**2*p(1)**2+8*d(1)*d(2)*p(1)*p(2)+2*d(1)**2*p(2)**2+6*d(2)**2*p(2)**2 &
& +2*d(3)**2*p(2)**2+8*d(1)*d(3)*p(1)*p(3)+8*d(2)*d(3)*p(2)*p(3)+2*d(1)**2*p(3)**2+2*d(2)**2*p(3)**2+6*d(3)**2*p(3)**2 &
& -2*d(1)**2*r**2-2*d(2)**2*r**2-2*d(3)**2*r**2-2*d(1)**2*xc**2-2*d(2)**2*xc**2+2*d(3)**2*xc**2-8*d(1)*d(3)*p(1)*zc &
& -8*d(2)*d(3)*p(2)*zc-4*d(1)**2*p(3)*zc-4*d(2)**2*p(3)*zc-12*d(3)**2*p(3)*zc+2*d(1)**2*zc**2+2*d(2)**2*zc**2+6*d(3)**2*zc**2

	dd(3) = 4*d(1)**3*p(1)+4*d(1)*d(2)**2*p(1)+4*d(1)*d(3)**2*p(1)+4*d(1)**2*d(2)*p(2)+4*d(2)**3*p(2)+4*d(2)*d(3)**2*p(2) &
& +4*d(1)**2*d(3)*p(3)+4*d(2)**2*d(3)*p(3)+4*d(3)**3*p(3)-4*d(1)**2*d(3)*zc-4*d(2)**2*d(3)*zc-4*d(3)**3*zc

	dd(4) = d(1)**4+2*d(1)**2*d(2)**2+d(2)**4+2*d(1)**2*d(3)**2+2*d(2)**2*d(3)**2+d(3)**4

	call quartic(dd, sol, soli, Nsol)

	if (Nsol.ge.2) then
	    t2 = maxval(sol)
	    tloc = maxloc(sol)
	    sol(tloc(1)) = 0
	    t1 = maxval(sol)
	else
	    t1 = 0
	    t2 = 0
	end if

	return
	end

