Atten4cubic.exe < par.txt
pause