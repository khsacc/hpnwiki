gfortran  -c getFP4PC.f90 -fdefault-real-8
gfortran -c getT.f90 -fdefault-real-8
pause