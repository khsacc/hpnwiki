gfortran -c getFP4PC.f90 -fdefault-real-8
gfortran Atten4pow.f90 gaulegf.o getlimit.o getFP4PC.o getT.o -o Atten4cubic.exe -fdefault-real-8
pause