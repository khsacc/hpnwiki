	program Atten4PalmCell

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!
!       Atten4PalmCell
!       
!	This program calculates the  flight path lengths of scattered neutron
!	pathed throgh anvils and gasket 
!	as a function of gamma (longitude) and nu (latitude)
!	focus and rebin in terms of 2th = 90deg
!
!
!	v0.1     08/July/2013  First draft
!	V1.0     15/July/2013  compile
!
!	written by K. Komatsu (U of Tokyo)
!	modified for Palm cubic anvil cell by J. Abe (CROSS-Tokai)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	implicit none

!! initialise
	integer :: i,j,k,l,g,n,gmax,nmax,numdir,LP1,LP2,LP3
	integer :: nlam						!number of lambda for mu file
	integer :: tmodbin(50000)				!bin # for modified time
	integer :: sw(50000)					!number of data in each bin in mu file
	integer :: numpar					!number of parameters
	integer :: numtofbin					!total number of tof bins
	integer :: ns,nstepR,nstepY,nstepT
	real :: gammas,gammae,gammastep,nus,nue,nustep		!start, end and step for gamma and nu
	double precision :: xmin,xmax,ymin,ymax,zmin,zmax			!min and max for sampling point, and GL step
	double precision :: xi(100),wi(100),xj(100),wj(100),xk(100),wk(100)	!x and w for Gauss-Legendre quadratures
	real :: p(4),d(4) 					!sampling points and diffraction vector, (x,y,z,1)
	real :: gp(10)						!Geometrical parameters for cell assembly
	real :: gamma,nu					!longitude and latitude angle for diffraction beam
	real :: sinth
	real :: r, th						!polar cordinate
	real :: FPI(10),FPD(10),FP(10)	,FPP			!flight path length from  p to i'th surface
	real :: lam(50000),mulam(50000),muerr(50000)		!lambda, mu(lam), and muerr(lam)
	real :: mutizr(50000),musample(50000),muasam,mubsam	!0.0125 * lam(i) + 0.0232, mutizr = musample = muasam * lam + mubsam
	real :: sumioi(50000)					!Summation of I/Io
	real :: weight,sumw,aioi

	real :: tmod,tmodcoef,tof, tofbinstep
	real :: L90

	real :: Time

	character*1 :: s
	character*80 :: ifile, ofile, mufile,TF1,TF2,TF3
	character*132 :: string

	real :: rad = 3.141592653589793/180.
	real :: deg = 180./3.141592653589793
	real :: pi = 3.141592653589793



!! Input user defined parameters
	write(*,*)' ///////////////////////////////////////  ' 
	write(*,*)' '
	write(*,*)' Atten4PalmCell'  
	write(*,*)' v1.0  08/July/2013 first draft'
	write(*,*)' '
	write(*,*)' ///////////////////////////////////////  ' 

	write(*,*)' '
	write(*,*)'Enter number of sampling poing'
	read *, nstepR
	read *, nstepT
	read *, nstepY

	write(*,*)' '
	write(*,*)'Enter number of parameters for cell assembly.'
	read *, numpar

	do i=1,numpar
	    write(*,*)' '
	    write(*,*)'Enter parameter ',i,' of cell assembly.'
	! in case of Palm cubic anvil cell, 1. Anvil top size, 2.anvil gap size, 3. sample phi, 4. sample hight, 5. gasket size and 6. gasket diagonal length
	    read *, gp(i)     		
	end do 

	gp(numpar+1:) = 0	! input dummy value for remaing ith parameter

	write(*,*)' '
	write(*,*)'Enter start and end angle of gamma(longitude), and their step (in degree).'
	read *, gammas,gammae,gammastep

	if ( (gammas.lt.70).or.(gammae.gt.120)) then
	    write(*,*)'gamma should be 85-95 deg. for Palm cubic anvil cell.'
	    write(*,*)'program is terminated.'
	    stop
	end if

	write(*,*)' '
	write(*,*)'Enter start and end angle of nu(latitude), and their step (in degree).'
	read *, nus,nue,nustep
	
	write(*,*)' '
	write(*,*)'Enter attenuation coefficient file for anvils with extention(e.g. wc_mu.dat,diam_mu.dat).'
	read(*,'(a80)')mufile

	write(*,*)' '
	write(*,*)'Enter attenuation coefficient for sample (musample = muasam * lam + mubsam).'
	read *, muasam,mubsam

	write(*,*)' '
	write(*,*)'Enter total number and step of tof bin (in microsec).'
	read *, numtofbin, tofbinstep

	write(*,*)' '
	write(*,*)'Enter total length of L from the moderator to the refference pixel.'
	write(*,*)' (L = 26.5 for PLANET, L=42 for TAKUMI).'
	read *, L90

!!!!!!!!!!!!!!! Initialising some parameters
! degrees to radians
	gammas = gammas * rad
	gammae = gammae * rad
	gammastep = gammastep * rad

	nus = nus * rad
	nue = nue * rad
	nustep = nustep * rad
	
! number of direction (Ngamma * Nnu)
	numdir = 0

! set 0 to sumioi
	sumioi = 0   

! set dummy number (1) for sampling point
	p = 1

! sw(i) : number of data in each bin in mu file
	sw(1:numtofbin) =0 

!!!!!!!!!!!!!!!   read mu file 
	mufile = trim(mufile)
	open(unit=11,file=mufile,status='old')

	do i = 1, 50000
	    read(11,*,end=29)lam(i),mulam(i),muerr(i)
	    nlam = i       		!read number of data point
	end do

29	close(11)


!!!!!!!!!!!!!!! set mu(lambda) for tizr and sample
	do l=1,nlam
	    mutizr(l) = 0.0125 * lam(l) + 0.0232
	    musample(l) = muasam * lam(l) + mubsam
	end do

!!!!!!!!!!!!!!!   Loop start

gmax = int( (gammae-gammas)/gammastep ) + 1
nmax = int( (nue-nus)/nustep ) + 1

LP1=nstepR
LP2=nstepT
LP3=nstepY

	numdir = 0
	sumioi = 0
	p = 1
	sw(1:numtofbin) =0 
gamma = gammas

!!!!!!!!!!!!!!!  Open flight path length output file
	write(TF1,'(I3)') LP1
	write(TF2,'(I3)') LP2
	write(TF3,'(I3)') LP3
	ofile='pathlength'//trim(TF1)//'-'//trim(TF2)//'-'//trim(TF3)//'.csv'
	ofile = trim(ofile)
	open(unit=1,file=ofile,status='replace')
	    write(1,'(a80)')'     gamma,        nu,       px,       py,       pz,   sample,     tizr,    anvil'


!!!!!!!!!!!!!!! Open output file for attenuation correction (tof, I/Io(tof))
	write(TF1,'(I3)') LP1
	write(TF2,'(I3)') LP2
	write(TF3,'(I3)') LP3
	ofile=trim(TF1)//'-'//trim(TF2)//'-'//trim(TF3)//'.csv'
	ofile = trim(ofile)
	open(unit=12,file=ofile,status='replace')

print *,ofile

do g = 1, gmax	
    nu = nus
    do n=1, nmax
	
	write(*,*) 'gamma :',gamma*deg,'  nu:',nu*deg, ' is processing.'
!	write(*,*) 'px: ', p(1), 'py: ', p(2), 'pz: ', p(3), ' sample    gasket(tizr)   anvil sum: ', sumw

	numdir = numdir + 1
	sumw = 0

	!calc diffraction vector
	d = (/ cos(nu)*sin(gamma), sin(nu), cos(nu)*cos(gamma), 0. /)

	!calc sin(theta) for time focusing, which is common for all sampling points and only depends on gamma and nu.
	sinth = sin(0.5*acos(cos(gamma)*cos(nu)))	
	tmodcoef = 178.74133 * L90 / sinth  ! t' = treal (L90 sin45)/(Lreal sinth), t = 252.7784131 * Lreal * lam

	! the tomdbin(i) is calculated here 
	do l = 1,nlam
		tmod = tmodcoef * lam(l)
		tmodbin(l) = int(tmod/tofbinstep) + 1
		if (tmodbin(l).eq.1) write(*,*)'tmodbin=1, when l= ',l, 'and tmodcoef= ',tmodcoef
		sw(tmodbin(l)) = sw(tmodbin(l)) + 1
	end do

	! calc x and w of Gauss-Legendre quadratures from gp

	do i=1,LP1
		r = (2*i -1)*gp(3)/4.0/LP1

	    do j=1,LP2
		th = 360.0/LP2 * j * rad
		p(1) = r * cos(th)
		p(3) = r * sin(th)

	        weight = pi/4.0/LP2*(gp(3)/LP1)**2*(2*i-1)*(gp(4)/LP3)

		do k=1,LP3
		    p(2) = gp(4)/2.0/LP3*(2*k-1-LP3)

		    do l=1,10
			FPI(l) = 0
			FPD(l) = 0
		    end do

		    call getFPinc4PC(p,gp,FPI)
		    call getFPdif4PC(p,d,gp,FPD)
		
		    FP = FPI+FPD
!		    write(*,'(6(10F8.2))')p(1),p(2),p(3),FP(1),FP(2),FP(3)
!		    write(1,'(8(10F12.6))')gamma*deg,nu*deg,p(1),p(2),p(3),FP(1),FP(2),FP(3)
		    write(1,'(7(F10.6 A) F10.6)')gamma*deg,',',nu*deg,',',p(1),',',p(2),',',p(3),',',FP(1),',',FP(2),',',FP(3)

		    if (FP(3).lt.1000) then      !!  -> if (FP(3).gt.1000) sumioi = sumioi + 0
		        do l=1,nlam
			    sumioi(tmodbin(l)) = sumioi(tmodbin(l)) + weight*exp(- mulam(l) * FP(3) - mutizr(l) * FP(2) - musample(l) * FP(1))
		        end do
		    end if
		    sumw = sumw + weight
		end do 			!k, p(3)
	    end do			!j, p(2)
	end do				!i, p(1)
	
	nu = nu + nustep
    end do 				!nu
    gamma = gamma + gammastep
end do 				!gamma

!average for all pixels
	write(*,*)'numdir: ',numdir,'sumw: ',sumw
	do i=1, numtofbin
	    tof = i*tofbinstep-tofbinstep/2.0
	    if (sw(i).ne.0) then
		aioi = sumioi(i)/sumw/sw(i)
	    else
		aioi = 0
	    end if
	    write(12,'(f10.4 A f10.4)')tof,',',aioi
	end do
  close(1)
  close(12)

 call cpu_time(Time)
 print *, Time, "sec."

	stop
	end






