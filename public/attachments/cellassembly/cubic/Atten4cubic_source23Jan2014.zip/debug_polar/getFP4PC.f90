!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	subroutine getFPinc4PC(p,gp,FPI)
	implicit none
	real, dimension(10),intent(in) :: gp
	real, dimension(4), intent(in) :: p
	real, dimension(10), intent(out) :: FPI		!1: sample, 2: TiZr, 3: WC
	real :: subtense

	subtense = sqrt( (gp(3)/2.0)**2 - p(1)*p(1) )		!subtence = sqrt((gp(3)/2)^2 - px^2)

	FPI(1) = subtense + p(3)			! sample

	if ( p(1) .gt. -gp(2)/2.0 .AND. p(1) .lt. gp(2)/2.0 ) then

	FPI(2) = -abs(p(1)) + gp(6)/2.0 - subtense	! TiZr
	FPI(3) = 0.0					! WC

	else

	FPI(2) = -abs(p(1)) + gp(1)/sqrt(2.0) +gp(2) - subtense			! TiZr
	FPI(3) = 2.0 * abs(p(1)) + 19.0/sqrt(2.0) - (gp(1)/sqrt(2.0) +gp(2))	! WC

	end if

!	write(*,*)'z1: ', z1, 'z2: ',z2
!	write(*,*)'p(1): ', p(1),'p(2): ',p(2),'p(3): ',p(3)
!	write(*,*)'FPI(1): ',FPI(1),'FPI(2): ',FPI(2),'FPI(3): ',FPI(3)

	return
	end

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	subroutine getFPdif4PC(p,d,gp,FPD)

!! this subroutine does 
!	1. calc t(i) for ith surface from p by using quadratic surface equation:
!	 a x2 + b y2 + c z2 + 2f yz + 2g zx + 2h xy + 2p x + 2q y + 2r z + d = 0
!	input Q(px + tdx, py + tdy, pz + tdz) to x, y, z in the eq. and solve in terms of t
!	with several conditions to judge the calculated Q is really acrocced with the surface.
!
!	2. sort t(i) as ascending order,and make rank(j)
!	3. calc flight paths from t(irank(j)) - t(rank(j-1))

	implicit none
	integer i
	real, dimension(10),intent(in) :: gp     		! 1: rgasket, 2:tgasket, 3:anvilgap
	real, dimension(4), intent(in) :: p, d   		! 1:x, 2:y, 3:z
	real, dimension(10), intent(out) :: FPD  		! 1: sample, 2: TiZr, 3: WC
	real :: len2,rps,zps,flag,a1,b1,c,tan7,xc,zc,r,z1,z2	! intermediate parameters
	real :: t(13),t1,t2					! pathlength from p to ith surface
	real :: len(13), qx(13), qy(13), qz(13)			! sqrt(x^2 + z^2), qx = px + t dx
	real :: tdummy(13)					! dummy parameter
	integer :: rank(13),minloc_array(1)			! ascending rank for ith surface (1-13)
	real, dimension(10) :: qsp				! Quadratic surface parameters
	
	
!!!!!!!!!!!!!!!!!!!!!
!  find cross point(s) 
!!!!!!!!!!!!!!!!!!!!!

!!!!S1
	qsp = (/ 1., 0., 1., 0., 0., 0., 0., 0., 0., -(gp(3)/2.)**2 /)
	call getT(qsp,p,d,t1,t2)
	t(1) = t1

!!!!S2
	qsp = (/ 0., 0., 0., 0., 0., 0., 1., 0., 1., -(gp(1)/sqrt(2.) + gp(2)) /)
	call getT(qsp,p,d,t1,t2)
	t(2) = t1

!!!!S3
	qsp = (/ 0., 0., 0., 0., 0., 0., -1., 0., 1., gp(1)/sqrt(2.) + gp(2) /)
	call getT(qsp,p,d,t1,t2)
	t(3) = t1

!!!!S4
	qsp = (/ 0., 0., 0., 0., 0., 0., 0., 0., 1., -gp(2)/2. /)
	call getT(qsp,p,d,t1,t2)
	t(4) = t1

!!!!S5
	qsp = (/ 0., 0., 0., 0., 0., 0., 0., 0., 1., gp(2)/2. /)
	call getT(qsp,p,d,t1,t2)
	t(5) = t1

!!!!S6 
	qsp = (/ 0., 0., 0., 0., 0., 0., -1., 0., 1., 19./sqrt(2.) /)
	call getT(qsp,p,d,t1,t2)
	t(6) = t1

!!!!S7
	qsp = (/ 0., 0., 0., 0., 0., 0., 1., 0., 1., -19./sqrt(2.) /)
	call getT(qsp,p,d,t1,t2)
	t(7) = t1

!!!!S8
	qsp = (/ 0., 0., 0., 0., 0., 0., 1., 0., 1., -gp(6)/2. /)
	call getT(qsp,p,d,t1,t2)
	t(8) = t1

!!!!S9
	qsp = (/ 0., 0., 0., 0., 0., 0., -1., 0., 1., gp(6)/2. /)
	call getT(qsp,p,d,t1,t2)
	t(9) = t1

!!!!S10
	qsp = (/ 0., 0., 0., 0., 0., 0., 0., 1., 0., -gp(4)/2. /)
	call getT(qsp,p,d,t1,t2)
	t(10) = t1

!!!!S11
	qsp = (/ 0., 0., 0., 0., 0., 0., 0., 1., 0., gp(4)/2. /)
	call getT(qsp,p,d,t1,t2)
	t(11) = t1

!!!!S12
	qsp = (/ 0., 0., 0., 0., 0., 0., 0., 1., 0., -gp(5)/2. /)
	call getT(qsp,p,d,t1,t2)
	t(12) = t1

!!!!S13
	qsp = (/ 0., 0., 0., 0., 0., 0., 0., 1., 0., gp(5)/2. /)
	call getT(qsp,p,d,t1,t2)
	t(13) = t1

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! judge the cross points really exist or not
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	do i=1, 13
		qx(i) = p(1) + t(i) * d(1)
		qy(i) = p(2) + t(i) * d(2)
		qz(i) = p(3) + t(i) * d(3)
		len(i) = ( (p(1) + t(i) * d(1))**2 + (p(3) +t(i) * d(3))**2 )**0.5 ! len = sqrt (qx^2 + qz^2)
	    if ( t(i).le.0 ) t(i) = 0  ! t(i) should have plus values if exist
	end do
	
!!!!! t(1) 
	if ( qy(1).lt.-gp(4)/2. .or. qy(1).gt. gp(4)/2. ) t(1) = 0
!!!!! t(2)
	if ( qx(2).lt.gp(2)/2. .or. qx(2).gt.(gp(1)/sqrt(2.) + gp(2)/2.) .or. qy(2).lt.-gp(1)/2. .or. qy(2).gt.gp(1)/2. ) t(2) = 0
!!!!! t(3)
	if ( qx(3).lt.gp(2)/2. .or. qx(3).gt.(gp(1)/sqrt(2.) + gp(2)/2.) .or. qy(3).lt.-gp(1)/2. .or. qy(3).gt.gp(1)/2. ) t(3) = 0
!!!!! t(4)
	if ( qx(4).lt.(gp(1)/sqrt(2.)+gp(2)/2.) .or. qx(4).gt.(19./sqrt(2.)+gp(2)/2.) .or. qy(4).lt.-19. .or. qy(4).gt.19. ) t(4) = 0
!!!!! t(5)
	if ( qx(5).lt.(gp(1)/sqrt(2.)+gp(2)/2.) .or. qx(5).gt.(19./sqrt(2.)+gp(2)/2.) .or. qy(5).lt.-19. .or. qy(5).gt.19. ) t(5) = 0
!!!!! t(6)
	if ( qx(6).lt.(19./sqrt(2.)+gp(2)/2.) .or. qx(6).gt.(24./sqrt(2.)+gp(2)/2.) .or. qy(6).lt.-19. .or. qy(6).gt.19. ) t(6) = 0
!!!!! t(7)
	if ( qx(7).lt.(19./sqrt(2.)+gp(2)/2.) .or. qx(7).gt.(24./sqrt(2.)+gp(2)/2.) .or. qy(7).lt.-19. .or. qy(7).gt.19. ) t(7) = 0
!!!!! t(8)
	if ( qx(8).lt.(gp(6)-gp(2))/2. .or. qx(8).gt.gp(6)/2. .or. qy(8).lt.-gp(5)/2. .or. qy(8).gt.gp(5)/2. ) t(8) = 0
!!!!! t(9)
	if ( qx(9).lt.(gp(6)-gp(2))/2. .or. qx(9).gt.gp(6)/2. .or. qy(9).lt.-gp(5)/2. .or. qy(9).gt.gp(5)/2. ) t(9) = 0
!!!!! t(10)
	if ( len(10).gt.gp(3)/2. ) t(10) = 0
!!!!! t(11)
	if ( len(11).gt.gp(3)/2. ) t(11) = 0
!!!!! t(12)
	if ( qx(12).gt.gp(6)/2. .or. qz(12).lt.(qx(12)-gp(6)/2.) .or. qz(12).gt.(-qx(12)+gp(6)/2.) ) t(12) = 0
!!!!! t(13)
	if ( qx(13).gt.gp(6)/2. .or. qz(13).lt.(qx(13)-gp(6)/2.) .or. qz(13).gt.(-qx(13)+gp(6)/2.) ) t(13) = 0

!	write(*,*)'t: '
!	write(*,'(13F6.2)') t

!!!!!!!!!!!!!!!!!!!!!!
!  make rank t(i)
!!!!!!!!!!!!!!!!!!!!!!

	tdummy = t  ! copy t to tdummy

	do i=1, 13
	    minloc_array = minloc(tdummy)   	   ! note: minloc_array is vector with dimension(1)
	    rank(i) = minloc_array(1)
	    tdummy(rank(i)) = 1000.		  ! put a dummy number larger than current max.
	end do


!!!!!!!!!!!!!!!!!!!!!!
! calc flight path
!!!!!!!!!!!!!!!!!!!!!!

	FPD = 0  ! initialise

	do i=1, 13   
	    if ( t(rank(i)).eq.0 ) cycle
!!!! S1
	    if ( (rank(i).eq.1) .and. (t(rank(i)).gt.0) ) FPD(1) = t(rank(i))
!!!! S2,3
	    if ( (rank(i).eq.2) .or. (rank(i).eq.3) .and. (t(rank(i)).gt.0) ) FPD(2) = t(rank(i)) - t(rank(i-1))
!!!! S4
	    if ( (rank(i).eq.4).and.(t(rank(i)).gt.0) ) then
		if (t(2).gt.0. .and. t(rank(i)).gt.0. ) FPD(3) = t(rank(i)) - t(rank(i-1))
		if (t(1).gt.0. .and. t(2).eq.0. .and. t(8).eq.0 .and. t(9).eq.0 .and. (t(rank(i)).gt.0) ) &
							& FPD(2) = FPD(2) + t(rank(i)) - t(rank(i-1))
	    end if
!!!! S5
	    if ( (rank(i).eq.5).and.(t(rank(i)).gt.0) ) then
		if ( (t(3).gt.0) .and. (t(rank(i)).gt.0) ) FPD(3) = t(rank(i)) - t(rank(i-1))
		if ( (t(1).gt.0) .and. (t(3).eq.0) .and. (t(8).eq.0) .and. (t(9).eq.0) .and. (t(rank(i)).gt.0) ) &
							&  FPD(2) = FPD(2) + t(rank(i)) - t(rank(i-1))
	    end if
!!!! S6,7
	    if ( (rank(i).eq.6) .or. (rank(i).eq.7) .and. (t(rank(i)).gt.0) ) FPD(3) = FPD(3) + t(rank(i)) - t(rank(i-1))
!!!! S8,9
	    if ( (rank(i).eq.8) .or. (rank(i).eq.9) .and. (t(rank(i)).gt.0) ) FPD(2) = FPD(2) + t(rank(i)) - t(rank(i-1))
!!!! S10,11
	    if ( (rank(i).eq.10) .or. (rank(i).eq.11) .and. (t(rank(i)).gt.0) ) FPD(1) = FPD(1) + t(rank(i))
!!!! S12,13
	    if ( (rank(i).eq.12) .or. (rank(i).eq.13) .and. (t(rank(i)).gt.0) ) FPD(2) = FPD(2) + t(rank(i))- t(rank(i-1))

	end do

!	write(*,*)'FPD(1): ',FPD(1), 'FPD(2): ',FPD(2), 'FPD(3): ',FPD(3)

	return
	end

