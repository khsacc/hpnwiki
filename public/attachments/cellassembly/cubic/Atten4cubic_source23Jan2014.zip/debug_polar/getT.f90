!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	subroutine getT(qsp,p,d,t1,t2)

	implicit none
	real, dimension(10), intent(in) :: qsp		! Quadratic surface parameters
	real, dimension(4), intent(in) :: p, d   	! 1:x, 2:y, 3:z, 4: 1
	real, intent(out) :: t1,t2			! 2 cross point
	real :: A, B, C					! t = -B +- ��(B^2-4AC) / 2A
	real, dimension(4) :: abc,fgh,pqrd, temp
	real :: flag

	abc = (/ qsp(1),qsp(2), qsp(3), 0. /)
	fgh = (/ qsp(4), qsp(5), qsp(6), 0. /)
	pqrd = (/ qsp(7), qsp(8), qsp(9), qsp(10)/)

!	write(*,*)'abc: ',abc
!	write(*,*)'fgh: ',fgh
!	write(*,*)'pqrd: ',pqrd

!!	for flat surface  t = -pqrd�Ep/pqrd�Ed
	if ( (qsp(1).eq.0).and.(qsp(2).eq.0).and.(qsp(3).eq.0).and.(qsp(4).eq.0).and.(qsp(5).eq.0).and.(qsp(6).eq.0) ) then
	    t1 = - dot_product(pqrd, p)/dot_product(pqrd, d)
	    t2 = t1

!!	for general surface
	else
	    temp = (/ d(2)*d(3), d(3)*d(1), d(1)*d(2), 0. /)
	    A = dot_product(abc, d*d) + dot_product(fgh, temp)

	    temp = (/ (p(2)*d(3)+p(3)*d(2)), (p(3)*d(1)+p(1)*d(3)), (p(1)*d(2)+p(2)*d(1)), 0. /) 
	    B = 2*dot_product(abc, p*d) + dot_product(fgh, temp) + dot_product(pqrd,d)

	    temp = (/ p(2)*p(3), p(3)*p(1), p(1)*p(2), 0. /)
	    C = dot_product(abc, p*p) + dot_product(fgh, temp) + dot_product(pqrd, p)

!		write(*,*)'A: ',A,'B: ',B,'C: ',C

	    flag = B*B - 4*A*C
!		write(*,*)'flag: ',flag
	    if ( (A.ne.0).and.(flag.ge.0) ) then    
		t1 = (-B + sqrt(flag))/(2*A)
	        t2 = (-B - sqrt(flag))/(2*A)
	    else if ( (A.ne.0).and.(flag.gt.-0.00001) ) then  !considering error
		t1 = -B/(2*A)
		t2 = t1
	    else if ( A.eq.0 ) then
		t1 = -C/B
		t2 = t1
	    else
		t1 = 0
		t2 = 0
	    end if

	end if

	return
	end
