!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	subroutine getxlimit4PC(gp,xmin,xmax)
	implicit none
	real, dimension(10),intent(inout) :: gp
	double precision, intent(out) :: xmin, xmax

	xmin = -gp(3)/2.0
	xmax = -xmin

	return
	end 

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	subroutine getylimit4PC(gp,ymin,ymax)

	implicit none
	real, dimension(10),intent(in) :: gp
	double precision, intent(out) :: ymin, ymax
	
	ymin = -gp(4)/2.0
	ymax = -ymin

	return
	end 

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	subroutine getzlimit4PC(p,gp,zmin,zmax)

	implicit none
	real, dimension(10),intent(in) :: gp
	real, dimension(4), intent(in) :: p
	double precision, intent(out) :: zmin, zmax
	
	zmin = -((gp(3)/2.0)**2-p(1)*p(1))**0.5
	zmax = -zmin

	return
	end 

