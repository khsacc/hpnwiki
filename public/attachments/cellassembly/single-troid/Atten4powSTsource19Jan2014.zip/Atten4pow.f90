	program Atten4pow

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!
!       Atten4pow
!       
!	This program calculates the  flight path lengths of scattered neutron
!	pathed throgh anvils and gasket 
!	as a function of gamma (longitude) and nu (latitude)
!	focus and rebin in terms of 2th = 90deg
!
!
!	v1.0     22/May/2010  First draft (modify by FlightPath4PEcell)
!	v2.0	 08/Jan/2013  drastic modification (Gauss-Legendre quadrature, direct FP calculation)
!	v2.1	 13/Jan/2014  rename all subroutine for more general case (not only for ST or DT)
!				like getFP4ST -> getFP
!	written by K. Komatsu (U of Tokyo)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	implicit none

!! initialise
	integer :: i,j,k,l,g,n,gmax,nmax,numdir
	integer :: nlam						!number of lambda for mu file
	integer :: tmodbin(50000)				!bin # for modified time
	integer :: sw(50000)					!number of data in each bin in mu file
	integer :: numpar					!number of parameters
	integer :: numtofbin					!total number of tof bins
	integer :: ns,nstep
	real :: gammas,gammae,gammastep,nus,nue,nustep		!start, end and step for gamma and nu
	double precision :: xmin,xmax,ymin,ymax,zmin,zmax			!min and max for sampling point, and GL step
	double precision :: xi(100),wi(100),xj(100),wj(100),xk(100),wk(100)	!x and w for Gauss-Legendre quadratures
	real :: p(4),d(4) 					!sampling points and diffraction vector, (x,y,z,1)
	real :: gp(10)						!Geometrical parameters for cell assembly
	real :: gamma,nu					!longitude and latitude angle for diffraction beam
	real :: sinth
	real :: FPI(10),FPD(10),FP(10)				!flight path length from  p to i'th surface
	real :: lam(50000),mulam(50000),muerr(50000)		!lambda, mu(lam), and muerr(lam)
	real :: mutizr(50000),musample(50000),muasam,mubsam	!0.0125 * lam(i) + 0.0232, mutizr = musample = muasam * lam + mubsam
	real :: sumioi(50000)					!Summation of I/Io
	real :: weight,sumw,aioi

	real :: tmod,tmodcoef,tof, tofbinstep
	real :: L90

	character*1 :: s
	character*80 :: ifile, ofile, mufile
	character*132 :: string

	real :: rad = 3.141592653589793/180.
	real :: deg = 180./3.141592653589793



!! Input user defined parameters
	write(*,*)' ///////////////////////////////////////  ' 
	write(*,*)' '
	write(*,*)' Atten4pow'  
	write(*,*)' v1.0  22/May/2010 first draft'
	write(*,*)' v2.0  08/Jan/2013 modified for G-L quadrature, FP calc, etc.'
	write(*,*)' '
	write(*,*)' ///////////////////////////////////////  ' 

	write(*,*)' '
	write(*,*)'Enter number of sampling poing for Gauss-Legendre quadratures'
	read *, nstep

	write(*,*)' '
	write(*,*)'Enter number of parameters for cell assembly.'
	read *, numpar

	do i=1,numpar
	    write(*,*)' '
	    write(*,*)'Enter parameter ',i,' of cell assembly.'
	! in case of phi9_6 and single toroid, 1. rgasket, 2.tgasket and 3. anvilgap.
	    read *, gp(i)     		
	end do 

	gp(numpar+1:) = 0	! input dummy value for remaing ith parameter

	write(*,*)' '
	write(*,*)'Enter start and end angle of gamma(longitude), and their step (in degree).'
	read *, gammas,gammae,gammastep

	if ( (gammas.lt.83).or.(gammae.gt.97)) then
	    write(*,*)'gamma should be 83-97 deg. for single troid anvil.'
	    write(*,*)'program is terminated.'
	    stop
	end if

	write(*,*)' '
	write(*,*)'Enter start and end angle of nu(latitude), and their step (in degree).'
	read *, nus,nue,nustep
	
	write(*,*)' '
	write(*,*)'Enter attenuation coefficient file for anvils with extention(e.g. wc_mu.dat,diam_mu.dat).'
	read(*,'(a80)')mufile

	write(*,*)' '
	write(*,*)'Enter attenuation coefficient for sample (musample = muasam * lam + mubsam).'
	read *, muasam,mubsam

	write(*,*)' '
	write(*,*)'Enter total number and step of tof bin (in microsec).'
	read *, numtofbin, tofbinstep

	write(*,*)' '
	write(*,*)'Enter total length of L from the moderator to the refference pixel.'
	write(*,*)' (L = 26.5 for PLANET, L=42 for TAKUMI).'
	read *, L90

	write(*,*)' '
	write(*,*)'Enter output file name with extention'
	read(*,'(a80)')ofile


!!!!!!!!!!!!!!! Open output file for attenuation correction (tof, I/Io(tof))
	ofile = trim(ofile)
	open(unit=12,file=ofile,status='replace')

!!!!!!!!!!!!!!! Initialising some parameters
! degrees to radians
	gammas = gammas * rad
	gammae = gammae * rad
	gammastep = gammastep * rad

	nus = nus * rad
	nue = nue * rad
	nustep = nustep * rad
	
! number of direction (Ngamma * Nnu)
	numdir = 0

! set 0 to sumioi
	sumioi = 0   

! set dummy number (1) for sampling point
	p = 1

! sw(i) : number of data in each bin in mu file
	sw(1:numtofbin) =0 

!!!!!!!!!!!!!!!   read mu file 
	mufile = trim(mufile)
	open(unit=11,file=mufile,status='old')

	do i = 1, 50000
	    read(11,*,end=29)lam(i),mulam(i),muerr(i)
	    nlam = i       		!read number of data point
	end do

29	close(11)


!!!!!!!!!!!!!!! set mu(lambda) for tizr and sample
	do l=1,nlam
	    mutizr(l) = 0.0125 * lam(l) + 0.0232
	    musample(l) = muasam * lam(l) + mubsam
	end do

!!!!!!!!!!!!!!!  Open flight path length output file
	open(unit=1,file='pathlength.dat',status='replace')
	    write(1,'(a80)')'     gamma        nu        px        py        pz    sample      tizr     anvil'


!!!!!!!!!!!!!!!   Loop start

gmax = int( (gammae-gammas)/gammastep ) + 1
nmax = int( (nue-nus)/nustep ) + 1

gamma = gammas
do g = 1, gmax	
    nu = nus
    do n=1, nmax
	
	write(*,*) 'gamma :',gamma*deg,'  nu:',nu*deg, ' is processing.'
!	write(*,*)'   px      py      pz     sample    tizr   anvil'

	numdir = numdir + 1
	sumw = 0

	!calc diffraction vector
	d = (/ cos(nu)*sin(gamma), sin(nu), cos(nu)*cos(gamma), 0. /)

	!calc sin(theta) for time focusing, which is common for all sampling points and only depends on gamma and nu.
	sinth = sin(0.5*acos(cos(gamma)*cos(nu)))	
	tmodcoef = 178.74133 * L90 / sinth  ! t' = treal (L90 sin45)/(Lreal sinth), t = 252.7784131 * Lreal * lam

	! the tomdbin(i) is calculated here 
	do l = 1,nlam
		tmod = tmodcoef * lam(l)
		tmodbin(l) = int(tmod/tofbinstep) + 1
		if (tmodbin(l).eq.1) write(*,*)'tmodbin=1, when l= ',l, 'and tmodcoef= ',tmodcoef
		sw(tmodbin(l)) = sw(tmodbin(l)) + 1
	end do

	! calc x and w of Gauss-Legendre quadratures from gp

	call getxlimit(gp,xmin,xmax)
	call GAULEGf(xmin,xmax,xi,wi,nstep)
	ns = nstep

	do i=1,ns
	    p(1) = xi(i)
	    call getylimit(p,gp,ymin,ymax)
	    call GAULEGf(ymin,ymax,xj,wj,nstep)

	    do j=1,ns
		p(2) = xj(j)
		call getzlimit(p,gp,zmin,zmax)
		call GAULEGf(zmin,zmax,xk,wk,nstep)

		do k=1,ns
		    p(3) = xk(k)
		
		    do l=1,10
			FPI(l) = 0
			FPD(l) = 0
		    end do

		    call getFPinc(p,gp,FPI)
		    call getFPdif(p,d,gp,FPD)
		
		    FP = FPI+FPD
!		    write(*,'(6(10F8.2))')p(1),p(2),p(3),FP(1),FP(2),FP(3)
		    write(1,'(8(10F10.4))')gamma*deg,nu*deg,p(1),p(2),p(3),FP(1),FP(2),FP(3)

		    weight = wi(i)*wj(j)*wk(k)
		    
		    if (FP(3).lt.1000) then      !!  -> if (FP(3).gt.1000) sumioi = sumioi + 0
		        do l=1,nlam
			    sumioi(tmodbin(l)) = sumioi(tmodbin(l)) + weight*exp(- mulam(l) * FP(3) - mutizr(l) * FP(2) - musample(l) * FP(1))
		        end do
		    end if
		    sumw = sumw + weight
		end do 			!k, p(3)
	    end do			!j, p(2)
	end do				!i, p(1)
	
	nu = nu + nustep
    end do 				!nu
    gamma = gamma + gammastep
end do 				!gamma

!average for all pixels
	write(*,*)'numdir: ',numdir,'sumw: ',sumw
	do i=1, numtofbin
	    tof = i*tofbinstep-tofbinstep/2.0
	    if (sw(i).ne.0) then
		aioi = sumioi(i)/sumw/sw(i)
	    else
		aioi = 0
	    end if
	    write(12,'(2f10.4)')tof,aioi
	end do

	stop
	end






