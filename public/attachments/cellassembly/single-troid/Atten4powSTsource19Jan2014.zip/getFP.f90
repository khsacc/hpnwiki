!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	subroutine getFPinc(p,gp,FPI)

!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!   for single troidal anvils
!!!!!!!!!!!!!!!!!!!!!!!!

	implicit none
	real, dimension(10),intent(in) :: gp
	real, dimension(4), intent(in) :: p
	real, dimension(10), intent(out) :: FPI  !1: sample, 2: TiZr, 3: WC
	real :: len2, z1,z2,z3

	len2 = p(1)*p(1) + p(2)*p(2)   !len2 = len^2 = (sqrt(px^2 + py^2))^2

	z1 = -(3.8*3.8 - len2)**0.5 + gp(5)     			!surface between anvil and Tizr
	z2 = (2.5*2.5 - len2)**0.5 - (2.5 + 6.5 + 1.5 + gp(3)/2)	!z2 is a back surface of wc hall
	z3 = -((3.8-gp(2))**2 - len2)**0.5 + gp(5)		!surface between Tizr and sample

!	write(*,*)'gp(2): ',gp(2),'len2: ',len2
!	write(*,*)'z1: ',z1,'z2: ',z2,'z3: ',z3

	FPI(1) = p(3) - z3  	! sample
	FPI(2) = z3 - z1	! TiZr
	FPI(3) = z1 - z2	! WC
!	write(*,*)'z1: ', z1, 'z2: ',z2
!	write(*,*)'p(1): ', p(1),'p(2): ',p(2),'p(3): ',p(3)
!	write(*,*)'FPI(1): ',FPI(1),'FPI(2): ',FPI(2),'FPI(3): ',FPI(3)

	return
	end

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	subroutine getFPdif(p,d,gp,FPD)

!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!   for single troidal anvils
!!!!!!!!!!!!!!!!!!!!!!!!


!! this subroutine does
!	1. calc t(i) for ith surface from p by using quadratic surface equation:
!	 a x2 + b y2 + c z2 + 2f yz + 2g zx + 2h xy + 2p x + 2q y + 2r z + d = 0
!	input Q(px + tdx, py + tdy, pz + tdz) to x, y, z in the eq. and solve in terms of t
!	with several conditions to judge the calculated Q is really acrocced with the surface.
!
!	2. sort t(i) as ascending order,and make rank(j)
!	3. calc flight paths from t(irank(j)) - t(rank(j-1))

	implicit none
	integer i
	real, dimension(10),intent(in) :: gp     		! 1: rgasket, 2:tgasket, 3:anvilgap
	real, dimension(4), intent(in) :: p, d   		! 1:x, 2:y, 3:z
	real, dimension(10), intent(out) :: FPD  		! 1: sample, 2: TiZr, 3: WC
	real :: len2,rps,zps,flag,a1,b1,c,tan7,xc,zc,r,z1,z2	! intermediate parameters
	real :: t(13),t1,t2					! pathlength from p to ith surface
	real :: len(13), qz(13)					! sqrt(x^2 + y^2), qz = pz + t dz
	real :: tdummy(13)					! dummy parameter
	integer :: rank(13),minloc_array(1)			! ascending rank for ith surface (1-13)
	real, dimension(10) :: qsp				! Quadratic surface parameters
	
	
!!!!!!!!!!!!!!!!!!!!!
!  find cross point(s) 
!!!!!!!!!!!!!!!!!!!!!
!!!!S1
	zps = 2.3 - gp(3)/2.
	rps = 3.8 - gp(2)
	qsp = (/ 1., 1., 1., 0., 0., 0., 0., 0., -2.*zps, zps**2 - rps**2 /)
	call getT(qsp,p,d,t1,t2)
	t(1) = t1

!!!!S2
	zps = -zps
	qsp = (/ 1., 1., 1., 0., 0., 0., 0., 0., -2.*zps, zps**2 - rps**2 /)
	call getT(qsp,p,d,t1,t2)
	t(2) = t1

!!!!S3
	zps = 2.3 - gp(3)/2.
	rps = 3.8
	qsp = (/ 1., 1., 1., 0., 0., 0., 0., 0., -2.*zps, zps**2 - rps**2 /)
	call getT(qsp,p,d,t1,t2)
	t(3) = t1

!!!!S4
	zps = -zps
	qsp = (/ 1., 1., 1., 0., 0., 0., 0., 0., -2.*zps, zps**2 - rps**2 /)
	call getT(qsp,p,d,t1,t2)
	t(4) = t1

!!!!S5
	qsp = (/ 0., 0., 0., 0., 0., 0., 0., 0., 1., -gp(3)/2. /)
	call getT(qsp,p,d,t1,t2)
	t(5) = t1

!!!!S6 
	qsp = (/ 0., 0., 0., 0., 0., 0., 0., 0., 1., gp(3)/2. /)
	call getT(qsp,p,d,t1,t2)
	t(6) = t1

!!!!S7&9
	xc = 6.55
	zc = 2. - 0.75 - gp(3)/2.
	r =  2.
	call getT4quartic(p,d,xc,zc,r,t1,t2)
	t(7) = t1
	t(9) = t2

!!!!S8&10
	zc = - zc
	call getT4quartic(p,d,xc,zc,r,t1,t2)
	t(8) = t1
	t(9) = t2

!!!!S11
	tan7 = 0.122784560902905   ! tan(radians(7))
	c = 5.*tan7 - gp(3)/2.
	qsp = (/  -tan7**2, -tan7**2, 1., 0., 0., 0., 0., 0., -2.*c*tan7, c**2 /)
	call getT(qsp,p,d,t1,t2)
	t(11) = t1

!!!!S12
	qsp = (/  -tan7**2, -tan7**2, 1., 0., 0., 0., 0., 0., 2.*c*tan7, c**2 /)
	call getT(qsp,p,d,t1,t2)
	t(12) = t1

!!!!S13
	qsp = (/ 1., 1., 0., 0., 0., 0., 0., 0., 0., -gp(1)**2 /)
	call getT(qsp,p,d,t1,t2)
	t(13) = t1

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! judge the cross points really exist or not
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	do i=1, 13
	    len(i) = ( (p(1) + t(i) * d(1))**2 + (p(2) +t(i) * d(2))**2 )**0.5
	    qz(i) = p(3) + t(i) * d(3)
	    if ( t(i).le.0 ) t(i) = 0  ! t(i) should have plus values if exist
	end do
	
!!!!! t(1) 
	if ( qz(1).gt.0) t(1) = 0
!!!!! t(2)
	if ( qz(2).lt.0) t(2) = 0
!!!!! t(3)
	if ( qz(3).gt.-gp(3)/2.0 ) t(3) = 0
!!!!! t(4)
	if ( qz(4).lt.gp(3)/2.0 ) t(4) = 0
!!!!! t(5)
	if ( (len(5).lt.3).or.(len(5).gt.5) ) t(5) = 0
!!!!! t(6)
	if ( (len(6).lt.3).or.(len(6).gt.5) ) t(6) = 0
!!!!! t(7)
	if ( (qz(7).gt.-gp(3)/2).or.(len(7).lt.5).or.(len(7).gt.6.55) ) t(7) = 0
!!!!! t(8)
	if ( (qz(8).lt.gp(3)/2).or.(len(8).lt.5).or.(len(8).gt.6.55) ) t(8) = 0
!!!!! t(9)
	if ( (t(7).eq.0).or.(len(9).lt.6.55).or.(len(9).gt.7.75) ) t(9) = 0
!!!!! t(10)
	if ( (t(8).eq.0).or.(len(10).lt.6.55).or.(len(10).gt.7.75) ) t(10) = 0
!!!!! t(11)
	if ( len(11).lt.7.75 ) t(11) = 0
!!!!! t(12)
	if ( len(12).lt.7.75 ) t(12) = 0
!!!!! t(13)
	if ( gp(1).le.7.75 ) then
	    xc = 6.55
	    zc = 2 -0.75 - gp(3)/2.
	    r = 2
	    z1 = -(r**2 - (gp(1)-xc)**2)**0.5 + zc
	    zc = -zc
	    z2 = (r**2 - (gp(1)-xc)**2)**0.5 + zc
	    if ( ( qz(13).lt.z1 ).or.(qz(13).gt.z2) ) t(13) = 0
	else
	    z1 = -tan7*len(13)+c
	    z2 = -z1
	    if ( ( qz(13).lt.z1 ).or.(qz(13).gt.z2) ) t(13) = 0
	end if

!	write(*,*)'t: '
!	write(*,'(13F6.2)') t

!!!!!!!!!!!!!!!!!!!!!!
!  make rank t(i)
!!!!!!!!!!!!!!!!!!!!!!

	tdummy = t  ! copy t to tdummy

	do i=1, 13
	    minloc_array = minloc(tdummy)   	   ! note: minloc_array is vector with dimension(1)
	    rank(i) = minloc_array(1)
	    tdummy(rank(i)) = 1000.		  ! put a dummy number larger than current max.
	end do


!!!!!!!!!!!!!!!!!!!!!!
! calc flight path
!!!!!!!!!!!!!!!!!!!!!!

	FPD = 0  ! initialise

	do i=1, 13   
	    if ( t(rank(i)).eq.0 ) cycle
!!!! S1,2
	    if ( ((rank(i).eq.1).or.(rank(i).eq.2)).and.(t(rank(i)).gt.0) ) FPD(1) = FPD(1) + t(rank(i))
!!!! S3,4
	    if ( ((rank(i).eq.3).or.(rank(i).eq.4)).and.(t(rank(i)).gt.0) ) FPD(2) = FPD(2) + t(rank(i)) - t(rank(i-1))
!!!! S5
	    if ( (rank(i).eq.5).and.(t(rank(i)).gt.0) ) then
		if ( d(3).gt.0 ) then
		    FPD(3) = FPD(3) + t(rank(i))-t(rank(i-1))
		else
		    FPD(2) = FPD(2) + t(rank(i))-t(rank(i-1))
		end if
	    end if
!!!! S6
	    if ( (rank(i).eq.6).and.(t(rank(i)).gt.0) ) then
		if ( d(3).lt.0 ) then
		    FPD(3) = FPD(3) + t(rank(i))-t(rank(i-1))
		else
		    FPD(2) = FPD(2) + t(rank(i))-t(rank(i-1))
		end if
	    end if
!!!! S7, 8
	    if ( ((rank(i).eq.7).or.(rank(i).eq.8)).and.(t(rank(i)).gt.0) ) FPD(3) = FPD(3) + t(rank(i))-t(rank(i-1))
!!!! S9, 10
	    if ( ((rank(i).eq.9).or.(rank(i).eq.10)).and.(t(rank(i)).gt.0) ) FPD(2) = FPD(2) + t(rank(i))-t(rank(i-1))
!!!! S11, 12
	    if ( ((rank(i).eq.11).or.(rank(i).eq.12)).and.(t(rank(i)).gt.0) ) then
		if ( (len(11).gt.12.5).or.(len(12).gt.12.5) ) then    !!!!! under the Cd sheet
		    FPD(3) = 10000
		else
		    FPD(3) = FPD(3) + t(rank(i))-t(rank(i-1))
		end if
	    end if
!!!! S13
	    if ( (rank(i).eq.13).and.(t(rank(i)).gt.0) ) FPD(2) = FPD(2) + t(rank(i))-t(rank(i-1))



	end do

!	write(*,*)'FPD(1): ',FPD(1), 'FPD(2): ',FPD(2), 'FPD(3): ',FPD(3)

	return
	end

