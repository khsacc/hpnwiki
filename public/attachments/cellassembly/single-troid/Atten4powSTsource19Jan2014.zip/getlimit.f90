!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!
!	getlimit for single troidal anvils
!

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	subroutine getxlimit(gp,xmin,xmax)
	implicit none
	real, dimension(10),intent(inout) :: gp
	double precision, intent(out) :: xmin, xmax
	real :: rps, zps

	rps = 3.8 - gp(2)
	zps = 1.5 + (1.6 - gp(3))/2.0    !1.5: initial zps, 1.6: initial anvilgap, gp(3): anvil gap

	gp(4) = rps
	gp(5) = zps

	xmin = -(rps*rps - zps*zps)**0.5
	if (xmin.le.-2.0) then
	    xmin = -2.0
	end if	
	xmax = -xmin


	return
	end 

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	subroutine getylimit(p,gp,ymin,ymax)

	implicit none
	real, dimension(10),intent(in) :: gp
	real, dimension(4), intent(in) :: p
	double precision, intent(out) :: ymin, ymax
	
	ymin = -(gp(4)*gp(4) - gp(5)*gp(5) - p(1)*p(1))**0.5
	if ( (ymin**2 + p(1)**2).ge.4.0) then
	    ymin = -(4.0-p(1)**2)**0.5
	end if
	ymax = -ymin

	
	return
	end 

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	subroutine getzlimit(p,gp,zmin,zmax)

	implicit none
	real, dimension(10),intent(in) :: gp
	real, dimension(4), intent(in) :: p
	double precision, intent(out) :: zmin, zmax
	
	zmin = -(gp(4)*gp(4) - p(1)*p(1) - p(2)*p(2))**0.5 + gp(5)
	zmax = -zmin

	return
	end 

